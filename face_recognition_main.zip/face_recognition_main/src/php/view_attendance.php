<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php");
    exit();
}
include 'header.php';
?>

<div class="content-container d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="member-content-box d-flex flex-column align-items-center justify-content-center text-center">
                <a href="main.php" class="brand-head d-flex align-items-center gap-3">
                        <div class="brand-icon"><i class="fa-solid fa-camera"></i></div>
                        <div class="brand-name">FaceAttend</div>
                    </a>
                    <h3>View Attendance Records by Date</h3>

                    <form class="w-100 d-flex align-items-center justify-content-center gap-3" action="view_attendance.php" method="post">
                        <div class="form-group flex-grow-1">
                            <input class="form-control" type="date" name="attendance_date" required>
                        </div>
                        <div class="flex-shrink-0">
                            <button class="btn btn-black btn-block" type="submit">View Records
                                <span class="btn-icon"><i class="fa-solid fa-clipboard-user"></i></span>
                            </button>
                        </div>
                        <div class="flex-shrink-0">
                        <a class="btn btn-black btn-block" href="index.php">
                                    <span class="btn-icon"><i class="fa-solid fa-chevron-left"></i></span>Go Back
                                </a>
                        </div>
                    </form>

                    <div class="w-100 attendance-records mt-5">
                        <h3>Attendance Records</h3>
                        
                        <?php
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            $attendance_date = $_POST['attendance_date'];

                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "face_recognition";

                            // Create connection
                            $conn = new mysqli($servername, $username, $password, $dbname);

                            // Check connection
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            // Fetch attendance records for the selected date
                            $sql = "SELECT name, timestamp FROM attendance WHERE DATE(timestamp) = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("s", $attendance_date);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                echo "<table class='table table-dark table-bordered table-striped'>";
                                echo "<tr><th>Name</th><th>Date</th><th>Time</th></tr>";
                                while ($row = $result->fetch_assoc()) {
                                    $date = date('Y-m-d', strtotime($row["timestamp"]));
                                    $time = date('H:i:s', strtotime($row["timestamp"]));
                                    echo "<tr><td class='text-capitalize'>" . htmlspecialchars($row["name"]) . "</td><td class='text-center'>" . htmlspecialchars($date) . "</td><td class='text-center'>" . htmlspecialchars($time) . "</td></tr>";
                                }
                                echo "</table>";
                            } else {
                                echo "<p>No attendance records available for the selected date.</p>";
                            }

                            $stmt->close();
                            $conn->close();
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
