<?php
// Get the name from the form input
$name = $_POST['name'];

// Define the path to the Python executable
$pythonPath = "C:\Python312\python.exe";

// Escape any special characters in the name to prevent issues in the command
$name = escapeshellarg($name);

// Call the Python script and pass the name as an argument
$pythonScriptPath = "C:\\xampp\\htdocs\\face_recognition_project-main\\src\\python\\add_faces.py";
$command = "$pythonPath $pythonScriptPath $name";
$output = shell_exec($command);

// Display the output from the Python script (for debugging purposes)
echo "<pre>";
print_r($output);
echo "</pre>";

// Redirect back to the homepage (optional)
header("Location: index.php");
exit();
?>
