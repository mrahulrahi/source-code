<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
include 'header.php';
?>


<div class="content-container d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 mx-auto">
                <div
                    class="member-content-box d-flex flex-column align-items-center justify-content-center text-center">
                    <a href="main.php" class="brand-head d-flex align-items-center gap-3">
                        <div class="brand-icon"><i class="fa-solid fa-camera"></i></div>
                        <div class="brand-name">FaceAttend</div>
                    </a>
                    <h3>Create your account</h3>

                    <form class="member-form" action="register.php" method="post">
                        <div class="form-group">
                            <input class="form-control" type="email" id="email" name="email" placeholder="Email address" required>
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="password" id="password" name="password" placeholder="Password" required>
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                        </div>
                        <div class="member-form-btn">
                            <button class="btn btn-black btn-block" type="submit">Sign up
                                <span class="btn-icon"><i class="fa-solid fa-user-plus"></i></span>
                            </button>
                        </div>
                    </form>

                    <div class="member-form-footer">
                        <p>Already have an account? <a class="btn-link" href="login.php">Sign in</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>