<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php");
    exit();
}
include 'header.php';
?>


<div class="content-container d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div
                    class="member-content-box d-flex flex-column align-items-center justify-content-center text-center">
                    <a href="main.php" class="brand-head d-flex align-items-center gap-3">
                        <div class="brand-icon"><i class="fa-solid fa-camera"></i></div>
                        <div class="brand-name">FaceAttend</div>
                    </a>
                    <h3>Add New Face or Take Attendance</h3>

                    <div class="w-75 d-flex flex-column align-items-center justify-content-center gap-3">
                        <form class="w-100 d-flex align-items-center justify-content-center gap-3" action="add_face.php"
                            method="post">
                            <div class="form-group flex-grow-1">
                                <input class="form-control" type="text" name="name" placeholder="Enter Your Name"
                                    required>
                            </div>
                            <div class="flex-shrink-0">
                                <button class="btn btn-black btn-block" type="submit">Add Face
                                    <span class="btn-icon"><i class="fa-regular fa-face-smile"></i></span>
                                </button>
                            </div>
                        </form>

                        <div class="w-100 d-flex align-items-center justify-content-center gap-3">
                            <form class="flex-shrink-0"
                                action="take_attendance.php" method="post">
                                <button class="btn btn-black btn-block" type="submit">Take Attendance
                                    <span class="btn-icon"><i class="fa-solid fa-clipboard-list"></i></span>
                                </button>
                            </form>
                            <div class="flex-shrink-0">
                                <a class="btn btn-black btn-block" href="view_attendance.php">Previous Records
                                    <span class="btn-icon"><i class="fa-solid fa-clipboard-user"></i></span>
                                </a>
                            </div>
                            <form class="flex-shrink-0" action="logout.php"
                                method="post">
                                <button class="btn btn-black btn-block" type="submit">Logout
                                    <span class="btn-icon"><i class="fa-solid fa-sign-out-alt"></i></span>
                                </button>
                            </form>
                        </div>


                    </div>

                    <div class="w-100 attendance-records mt-5">

                        <h3>Attendance Records</h3>

                        <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "face_recognition";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch current date's attendance records from the database
$sql = "SELECT name, timestamp FROM attendance WHERE DATE(timestamp) = CURDATE()";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table class='table table-dark table-bordered table-striped'>";
    echo "<tr><th>Name</th><th>Date</th><th>Time</th></tr>";
    while($row = $result->fetch_assoc()) {
        $date = date('Y-m-d', strtotime($row["timestamp"]));
        $time = date('H:i:s', strtotime($row["timestamp"]));
        echo "<tr><td class='text-capitalize'>" . htmlspecialchars($row["name"]) . "</td><td class='text-center'>" . htmlspecialchars($date) . "</td><td class='text-center'>" . htmlspecialchars($time) . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>No attendance records available for today.</p>";
}

$conn->close();
?>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>