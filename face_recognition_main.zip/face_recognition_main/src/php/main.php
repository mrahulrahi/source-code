<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
include 'header.php';
?>

<div class="content-container d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 mx-auto">
                <div
                    class="landing-content-box d-flex flex-column align-items-center justify-content-center text-center">
                    <a href="main.php" class="brand-head d-flex align-items-center gap-3">
                        <div class="brand-icon"><i class="fa-solid fa-camera"></i></div>
                        <div class="brand-name">FaceAttend</div>
                    </a>
                    <h3>Revolutionize attendance <br> tracking with face recognition</h3>

                    <div class="landing-btn-wrap d-flex align-items-center gap-3">
                        <a href="login.php" class="btn btn-black">Login
                            <span class="btn-icon"><i class="fa-solid fa-right-to-bracket"></i></span>
                        </a>
                        <a href="signup.php" class="btn btn-white">Signup
                            <span class="btn-icon"><i class="fa-solid fa-user-plus"></i></span>
                        </a>
                    </div>

                    <p>Join thousands of organizations already benefiting from our cutting-edge face
                        recognition technologyfor accurate and efficient attendance management.</p>
                </div>

            </div>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>