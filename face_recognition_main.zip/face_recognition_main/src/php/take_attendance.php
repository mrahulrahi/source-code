<?php

// Define the path to the Python executable
$pythonPath = "C:\Python312\python.exe";

// Call the Python script and pass the name as an argument
$pythonScriptPath = "C:\\xampp\\htdocs\\face_recognition_project-main\\src\\python\\test.py";
$command = escapeshellcmd("$pythonPath $pythonScriptPath 2>&1"); // Redirect standard error to standard output

// Execute the command and capture the output and return status
$output = [];
$returnVar = 0;
exec($command, $output, $returnVar);

// Display the output from the Python script
echo "<pre>";
print_r($output);
echo "</pre>";

// Check for errors
if ($returnVar !== 0) {
    echo "<strong>Error:</strong> The Python script encountered an error. Return code: $returnVar<br>";
    // Display the output (including errors)
    echo "<strong>Output:</strong><br>";
    echo "<pre>" . implode("\n", $output) . "</pre>";
}

// Redirect back to the homepage (optional)
header("Location: index.php");
exit();
?>