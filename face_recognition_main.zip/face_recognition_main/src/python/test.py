import cv2
import pickle
import numpy as np
import os
import time
from datetime import datetime
from sklearn.neighbors import KNeighborsClassifier
from win32com.client import Dispatch
import traceback
import mysql.connector

def speak(str1):
    speak = Dispatch(("SAPI.SpVoice"))
    speak.Speak(str1)

try:
    video = cv2.VideoCapture(0)
    facedetect = cv2.CascadeClassifier('C:/xampp/htdocs/face_recognition_project-main/data/haarcascade_frontalface_default.xml')

    # Load the data
    with open('C:/xampp/htdocs/face_recognition_project-main/data/names.pkl', 'rb') as w:
        LABELS = pickle.load(w)
    with open('C:/xampp/htdocs/face_recognition_project-main/data/faces_data.pkl', 'rb') as f:
        FACES = pickle.load(f)

    # Ensure FACES and LABELS have the same number of samples
    print('Original Shape of Faces matrix --> ', FACES.shape)
    print('Original Length of Labels array --> ', len(LABELS))

    if FACES.shape[0] != len(LABELS):
        min_samples = min(FACES.shape[0], len(LABELS))
        FACES = FACES[:min_samples]
        LABELS = LABELS[:min_samples]

    print('Adjusted Shape of Faces matrix --> ', FACES.shape)
    print('Adjusted Length of Labels array --> ', len(LABELS))

    # Get the number of features from the training data
    n_features = FACES.shape[1]
    print(f'Number of features: {n_features}')

    # Train the KNN classifier
    knn = KNeighborsClassifier(n_neighbors=5)
    knn.fit(FACES, LABELS)

    imgBackground = cv2.imread("C:/xampp/htdocs/face_recognition_project-main/src/background.png")
    if imgBackground is None:
        raise FileNotFoundError("background.png not found or could not be loaded")

    COL_NAMES = ['NAME', 'TIME']
    while True:
        ret, frame = video.read()
        if not ret:
            print("Failed to capture image from camera")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = facedetect.detectMultiScale(gray, 1.3, 5)
        attendance_records = []  # List to store attendance records for all detected faces

        for (x, y, w, h) in faces:
            crop_img = frame[y:y + h, x + w, :]
            resized_img = cv2.resize(crop_img, (50, 50))
            flattened_img = resized_img.flatten()

            # Ensure the flattened image has the same number of features as the training data
            if len(flattened_img) > n_features:
                flattened_img = flattened_img[:n_features]
            elif len(flattened_img) < n_features:
                flattened_img = np.pad(flattened_img, (0, n_features - len(flattened_img)))

            input_img = flattened_img.reshape(1, -1)
            output = knn.predict(input_img)

            ts = time.time()
            date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
            timestamp = datetime.fromtimestamp(ts).strftime("%H:%M-%S")

            # Draw rectangles and put text for each face
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (50, 50, 255), 2)
            cv2.rectangle(frame, (x, y - 40), (x + w, y), (50, 50, 255), -1)
            cv2.putText(frame, str(output[0]), (x, y - 15), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (50, 50, 255), 1)

            attendance = [str(output[0]), str(timestamp)]
            attendance_records.append(attendance)

        # Resize the frame to match the background dimensions
        resized_frame = cv2.resize(frame, (640, 480))
        imgBackground[162:162 + 480, 55:55 + 640] = resized_frame
        cv2.imshow("Frame", imgBackground)
        k = cv2.waitKey(1)

        if k == ord('o'):
            time.sleep(3)

            # Initialize a set to track names that have already been recorded
            recorded_names = set()

            # Connect to the MySQL database
            try:
                conn = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="face_recognition"
                )
                cursor = conn.cursor()
                print("Database connection successful")

                # Check if the names have already been recorded
                cursor.execute("SELECT name FROM attendance WHERE DATE(timestamp) = CURDATE()")
                for row in cursor.fetchall():
                    recorded_names.add(row[0])

                new_attendance_taken = False  # Flag to check if any new attendance was recorded

                for record in attendance_records:
                    name = record[0]
                    if name in recorded_names:
                        speak(f"{name}, your attendance has already been taken.")
                    else:
                        cursor.execute("INSERT INTO attendance (name, timestamp) VALUES (%s, %s)", (name, datetime.now()))
                        conn.commit()
                        print(f"Inserted record for {name} at {datetime.now()}")
                        recorded_names.add(name)  # Add the name to the set after writing
                        new_attendance_taken = True  # Set the flag if a new record is added

                if new_attendance_taken:
                    speak("Attendance Taken.")

                cursor.close()
                conn.close()
            except mysql.connector.Error as err:
                print(f"Error: {err}")

        if k == ord('q'):
            break

except Exception as e:
    print("An error occurred:")
    print(e)
    traceback.print_exc()

finally:
    video.release()
    cv2.destroyAllWindows()