jQuery(document).ready(function ($) {


  /*==========================*/
  /* Scroll on animate */
  /*==========================*/
  function onScrollInit(items, trigger) {
    items.each(function () {
      var osElement = $(this),
        osAnimationClass = osElement.attr('data-os-animation'),
        osAnimationDelay = osElement.attr('data-os-animation-delay');
      osElement.css({
        '-webkit-animation-delay': osAnimationDelay,
        '-moz-animation-delay': osAnimationDelay,
        'animation-delay': osAnimationDelay
      });
      var osTrigger = (trigger) ? trigger : osElement;
      osTrigger.waypoint(function () {
        osElement.addClass('animated').addClass(osAnimationClass);
      }, {
        triggerOnce: true,
        offset: '95%',
      });
    });
  }
  onScrollInit($('.os-animation'));

  /* Header search box start */
  if ($(".header-search-box").length > 0) {
    const divs = document.querySelectorAll(".header-search-box");
    divs.forEach((div) => {
      div.addEventListener("click", function () {
        document.body.classList.toggle("search-box-open");
      });
    });
  };
  /* Header search box end */

  /* Mobile nav menu start */
  if ($(".nav-icon").length > 0) {
    document.querySelector(".nav-icon").addEventListener("click", function () {
      document.body.classList.toggle("navopen");
    });
  }
  /* Mobile nav menu end */

  /*==========================*/
  /* push menu */
  /*==========================*/

  if ($("#mp-menu").length > 0) {
    new mlPushMenu(document.getElementById("mp-menu"), document.getElementById("trigger"), {
      type: "cover",
    });
  }


  /*==========================*/
  /* Logo carousel with conditions start */
  /*==========================*/
  if (document.querySelector(".all-logo-list")) {
    const mediaQueryLarge = window.matchMedia("(min-width: 993px)");
    const mediaQueryMid = window.matchMedia("(min-width:577px) and (max-width: 992px)");
    const mediaQuerySmall = window.matchMedia("(max-width: 576px)");
    // Check if the media query is true
    if (mediaQueryLarge.matches) {
      $(".all-logo-list").each(function () {
        var totalLogos = $(this).children(".logo-child").length;
        if (totalLogos > 10) {
          $(this).closest(".logo-parent").addClass("logoScroll");
          $(this).clone().insertAfter(this);
        }
      });
    } else if (mediaQueryMid.matches) {
      $(".all-logo-list").each(function () {
        var totalLogos = $(this).children(".logo-child").length;
        if (totalLogos > 3) {
          $(this).closest(".logo-parent").addClass("logoScroll");
          $(this).clone().insertAfter(this);
        }
      });
    } else if (mediaQuerySmall.matches) {
      $(".all-logo-list").each(function () {
        var totalLogos = $(this).children(".logo-child").length;
        if (totalLogos > 2) {
          $(this).closest(".logo-parent").addClass("logoScroll");
          $(this).clone().insertAfter(this);
        }
      });
    }
  }


  /*==========================*/
  /* All sliders */
  /*==========================*/
  /* Slider for Home page hero start */
  if (document.querySelector(".home-hero-image-slider")) {
    heroImageSwiper = new Swiper(".home-hero-image-slider", {
      slidesPerView: 1,
      effect: "fade",
      loop: true,
    });
  }



  /*==========================*/
  /* Header fix */
  /*==========================*/
  var scroll = $(window).scrollTop();
  if (scroll >= 40) {
    $("body").addClass("fixed");
  } else {
    $("body").removeClass("fixed");
  }

});


$(window).scroll(function () {
  var scroll = $(window).scrollTop();
  if (scroll >= 40) {
    $("body").addClass("fixed");
  } else {
    $("body").removeClass("fixed");
  }
});



// Sidebar toggle for mobile
$(document).ready(function() {
    $('#sidebarToggle').on('click', function() {
        $('.profile-sidebar').toggleClass('show');
    });

    // Close sidebar when clicking outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.profile-sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
            $('.profile-sidebar').removeClass('show');
        }
    });
});
